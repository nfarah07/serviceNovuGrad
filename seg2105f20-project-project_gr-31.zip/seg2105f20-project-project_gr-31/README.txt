Members:
Jonah Cantello #300112348
Comtois Amélie #300061996
Nastexa Farah #300018467
Derek Hacault-Parodi #300122544
Ansh Patel #300102472

Link to repository: https://github.com/SEG2105-uottawa/seg2105f20-project-project_gr-31.git
