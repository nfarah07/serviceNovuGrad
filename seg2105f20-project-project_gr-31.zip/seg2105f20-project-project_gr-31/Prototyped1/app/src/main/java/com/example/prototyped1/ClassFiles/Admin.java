package com.example.prototyped1.ClassFiles;



public class Admin extends Account {
    public Admin(String email, String pass){
        super(email,pass);
    }
}
